package com.example.myapp.dnd;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * Главный класс приложения (JavaFX).
 * Запускает главное окно (меню) при старте.
 */
public class MainApp extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Загружаем FXML-файл главного меню
        FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/fxml/main-menu.fxml")
        );
        Parent root = loader.load();

        // Создаём сцену
        Scene scene = new Scene(root, 600, 400);

        // Настраиваем Stage
        primaryStage.setTitle("DnD Master Menu");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        // Запускает JavaFX-приложение.
        // Внутри будет вызван start(Stage).
        launch(args);
    }
}
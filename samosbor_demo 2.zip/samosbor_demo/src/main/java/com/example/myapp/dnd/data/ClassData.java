package com.example.myapp.dnd.data;

import java.util.*;

public class ClassData {

    // Список доступных классов
    public static final List<String> CLASSES = new ArrayList<>();

    // Диапазоны навыков
    // Пример: "Офицер службы безопасности" -> { "Оружие" -> [20,35], "Медицина" -> [10,20], ... }
    public static final Map<String, Map<String, int[]>> SKILL_RANGES = new HashMap<>();

    static {
        // Наполняем список классов
        CLASSES.add("Офицер службы безопасности");
        CLASSES.add("Доктор");
        CLASSES.add("Инженер");
        CLASSES.add("Механик");
        CLASSES.add("Помощник");

        // Пример для "Офицер службы безопасности"
        Map<String, int[]> officerSkills = new HashMap<>();
        officerSkills.put("Оружие", new int[]{20, 35});
        officerSkills.put("Медицина", new int[]{10, 20});
        officerSkills.put("Механика", new int[]{10, 20});
        officerSkills.put("Электроника", new int[]{10, 20});

        SKILL_RANGES.put("Офицер службы безопасности", officerSkills);

        // Пример для "Доктор"
        Map<String, int[]> doctorSkills = new HashMap<>();
        doctorSkills.put("Оружие", new int[]{10, 20});
        doctorSkills.put("Медицина", new int[]{20, 35});
        doctorSkills.put("Механика", new int[]{10, 20});
        doctorSkills.put("Электроника", new int[]{10, 20});

        SKILL_RANGES.put("Доктор", doctorSkills);

        // Аналогично для "Инженер"
        Map<String, int[]> engineerSkills = new HashMap<>();
        engineerSkills.put("Оружие", new int[]{10, 20});
        engineerSkills.put("Медицина", new int[]{10, 20});
        engineerSkills.put("Механика", new int[]{10, 20});
        engineerSkills.put("Электроника", new int[]{20, 35});
        SKILL_RANGES.put("Инженер", engineerSkills);

        // "Механик"
        Map<String, int[]> mechanicSkills = new HashMap<>();
        mechanicSkills.put("Оружие", new int[]{10, 20});
        mechanicSkills.put("Медицина", new int[]{10, 20});
        mechanicSkills.put("Механика", new int[]{20, 35});
        mechanicSkills.put("Электроника", new int[]{10, 20});
        SKILL_RANGES.put("Механик", mechanicSkills);

        // "Помощник"
        Map<String, int[]> assistantSkills = new HashMap<>();
        assistantSkills.put("Оружие", new int[]{15, 25});
        assistantSkills.put("Медицина", new int[]{15, 25});
        assistantSkills.put("Механика", new int[]{15, 25});
        assistantSkills.put("Электроника", new int[]{15, 25});
        SKILL_RANGES.put("Помощник", assistantSkills);
    }

    private ClassData() {
        // закрытый конструктор, чтобы никто не создавал экземпляр
    }
}
package com.example.myapp.dnd.editor;

import com.example.myapp.dnd.characters.Character;
import com.example.myapp.dnd.data.ClassData;
import com.example.myapp.dnd.data.FeatureData;
import com.example.myapp.dnd.data.Feature;
import com.example.myapp.dnd.data.TalentData;
import com.example.myapp.dnd.storage.Storage;

import java.util.List;
import java.util.Map;

/**
 * Сервис, отвечающий за редактирование персонажа:
 * - Загрузка/сохранение
 * - Изменение статов
 * - Обновление уровня
 * - Разблокировка талантов
 * - Поиск описания (класс, фичи, таланты)
 */
public class CharacterEditorService {

    /**
     * Загрузить персонажа по имени (или вернуть null, если не найден).
     */
    public static Character loadCharacter(String characterName) {
        return Storage.loadCharacter(characterName);
    }

    /**
     * Сохранить изменения в персонаже (записать JSON).
     */
    public static void saveChanges(Character character) {
        Storage.saveCharacter(character);
    }

    /**
     * Изменить указанный стат (strength/agility/stamina/experience) на delta.
     * Если stat = "experience", дополнительно пересчитываем уровень.
     */
    public static void modifyStat(Character character, String stat, int delta) {
        // В зависимости от stat — увеличиваем/уменьшаем поле
        switch (stat) {
            case "strength":
            case "agility":
            case "stamina":
                // Берём текущее значение и добавляем delta, не даём опуститься ниже 0
                int oldValue = getStatValue(character, stat);
                int newValue = Math.max(0, oldValue + delta);
                setStatValue(character, stat, newValue);
                break;

            case "experience":
                int expOld = character.getExperience();
                int expNew = Math.max(0, expOld + delta);
                character.setExperience(expNew);
                updateLevel(character);
                break;

            default:
                // Можно ничего не делать или бросить ошибку
                throw new IllegalArgumentException("Неизвестный стат: " + stat);
        }
    }

    /**
     * Уровень считается из опыта: пока exp >= expRequired, level++
     * expRequired начально = 950, после каждого апа растёт на 450
     */
    private static void updateLevel(Character character) {
        int exp = character.getExperience();
        int level = 0;
        int expRequired = 950;

        while (exp >= expRequired) {
            level++;
            exp -= expRequired;
            expRequired += 450;
        }

        character.setLevel(level);
    }

    /**
     * Разблокировать талант по имени: ищем в ALL_TALENTS
     * для класса персонажа (например, "TALENTS_OFFICER"), перебираем ранги/деревья
     */
    public static boolean unlockTalent(Character character, String talentName) {
        // Предположим, есть мапа: "Офицер" -> "TALENTS_OFFICER"
        // но вы можете хранить это и в ClassData (CLASS_TALENTS) или ещё где-то
        // Если у вас такой мапы нет — найдите другой способ определить ключ (TALENTS_OFFICER и т.д.)

        // Как вариант:
        // String talentKey = ClassData.CLASS_TALENTS.get(character.getCharClass());
        // Но если нет, можно вручную сопоставлять имя класса -> ключ

        // Для примера:
        String className = character.getCharClass();
        String talentKey = getTalentKeyByClassName(className);
        if (talentKey == null) {
            return false;
        }

        // Получаем вложенную структуру
        Map<String, Map<String, Map<String, Object>>> talentsForClass =
                TalentData.ALL_TALENTS.get(talentKey);

        if (talentsForClass == null) {
            return false;
        }

        // Перебираем ранги/деревья (value = Map<talentName, Map<"description", ...>>)
        for (Map<String, Map<String, Object>> rankOrTree : talentsForClass.values()) {
            // rankOrTree: "Ранг 1" -> { "Универсал" -> { "description"->... }, ... }
            for (Map.Entry<String, Map<String, Object>> talentEntry : rankOrTree.entrySet()) {
                String currentTalentName = talentEntry.getKey();
                if (currentTalentName.equals(talentName)) {
                    // Нашли нужный талант!
                    // Добавим в список talents персонажа
                    List<String> charTalents = character.getTalents();
                    // Проверим, нет ли такого таланта уже
                    if (!charTalents.contains(talentName)) {
                        charTalents.add(talentName);
                    }
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Возвращает описание для itemName:
     * 1) Смотрим, не является ли это названием класса (если есть такая мапа).
     * 2) Ищем в FeatureData (сравниваем feature.getName()).
     * 3) Ищем в TalentData (ALL_TALENTS).
     * Если не нашли — "Описание не найдено."
     */
    public static String getDescription(String itemName) {
        // (1) Если у вас есть ClassData с описаниями классов (CLASS_DESCRIPTIONS),
        //     можно сначала там проверить. Пример (если его храните):
        //
        // if (ClassData.CLASS_DESCRIPTIONS.containsKey(itemName)) {
        //     return ClassData.CLASS_DESCRIPTIONS.get(itemName);
        // }

        // (2) Ищем в FEATURES
        for (Feature f : FeatureData.FEATURES) {
            if (f.getName().equals(itemName)) {
                return f.getDescription();
            }
        }

        // (3) Ищем в TalentData.ALL_TALENTS
        // ALL_TALENTS = Map<"TALENTS_MECHANIC", Map<"Ранг 1", Map<"Универсал", {desc}>>>
        for (Map<String, Map<String, Map<String, Object>>> talentsForClass
                : TalentData.ALL_TALENTS.values()) {

            // talentsForClass: "Ранг" или "Дерево"
            for (Map<String, Map<String, Object>> rankOrTree : talentsForClass.values()) {
                // rankOrTree: "Универсал" -> { "description"->... }
                for (Map.Entry<String, Map<String, Object>> entry : rankOrTree.entrySet()) {
                    String talentName = entry.getKey(); // "Универсал"
                    Map<String, Object> talentData = entry.getValue(); // {"description"-> "..."}
                    if (talentName.equals(itemName)) {
                        return (String) talentData.getOrDefault("description",
                                "Описание отсутствует.");
                    }
                }
            }
        }

        return "Описание не найдено.";
    }


    // ------------------------------------------------------
    // ВНУТРЕННИЕ ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ
    // ------------------------------------------------------

    /**
     * Получить текущее значение (strength / agility / stamina) из Character.
     */
    private static int getStatValue(Character character, String stat) {
        switch (stat) {
            case "strength": return character.getStrength();
            case "agility":  return character.getAgility();
            case "stamina":  return character.getStamina();
            default: throw new IllegalArgumentException("Неизвестный стат: " + stat);
        }
    }

    /**
     * Установить новое значение для (strength / agility / stamina).
     */
    private static void setStatValue(Character character, String stat, int value) {
        switch (stat) {
            case "strength": character.setStrength(value); break;
            case "agility":  character.setAgility(value);  break;
            case "stamina":  character.setStamina(value);  break;
            default: throw new IllegalArgumentException("Неизвестный стат: " + stat);
        }
    }

    /**
     * Условная функция для сопоставления названия класса (Напр. "Механик")
     * -> ключ набора талантов ("TALENTS_MECHANIC").
     * В Python у вас было CLASS_TALENTS = { "Механик": "TALENTS_MECHANIC" }.
     * Можно хранить это в ClassData, но пока сделаем здесь вручную для примера.
     */
    private static String getTalentKeyByClassName(String className) {
        switch (className) {
            case "Механик": return "TALENTS_MECHANIC";
            case "Офицер службы безопасности": return "TALENTS_OFFICER";
            case "Доктор": return "TALENTS_DOCTOR";
            case "Инженер": return "TALENTS_ENGINEER";
            case "Помощник": return "TALENTS_ASSISTANT";
            default: return null;
        }
    }
}
package com.example.myapp.dnd.samosbor;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.util.Duration;

/**
 * Контроллер для окна/сцены "Система Самосбор".
 * Связан с FXML (samosbor.fxml).
 */
public class SamosborController {

    @FXML
    private Label statusLabel;  // Показывает текущий статус
    @FXML
    private Label lastSamosborLabel; // "Время с последнего самосбора"
    @FXML
    private Label overallTimerLabel; // "Общее время"

    @FXML
    private Button startButton;
    @FXML
    private Button pauseButton;
    @FXML
    private Button resumeButton;
    @FXML
    private Button manualButton;
    @FXML
    private Button stopButton;

    // Менеджер самосбора
    private SamosborManager manager;

    // Таймер обновления UI
    private Timeline uiUpdater;

    @FXML
    public void initialize() {
        // Создаём экземпляр нашего менеджера.
        manager = new SamosborManager();

        // Запускаем анимационный Timeline, который раз в 1 секунду вызывает updateUI().
        uiUpdater = new Timeline(
                new KeyFrame(Duration.seconds(1), event -> updateUI())
        );
        uiUpdater.setCycleCount(Timeline.INDEFINITE);
        uiUpdater.play();

        // Устанавливаем начальные значения на экране
        updateUI();
        statusLabel.setText("Система готова.");
    }

    /**
     * Кнопка "Пуск"
     */
    @FXML
    private void onStart() {
        manager.start();
        statusLabel.setText("Оценка случайного события запущена.");
    }

    /**
     * Кнопка "Пауза"
     */
    @FXML
    private void onPause() {
        manager.pause();
        statusLabel.setText("Оценка случайного события приостановлена.");
    }

    /**
     * Кнопка "Возобновить"
     */
    @FXML
    private void onResume() {
        manager.resume();
        statusLabel.setText("Оценка случайного события возобновлена.");
    }

    /**
     * Кнопка "Ручной Самосбор"
     */
    @FXML
    private void onManualSamosbor() {
        manager.manualSamosbor();
        statusLabel.setText("Ручной самосбор (принудительный).");
        // После этого manager.triggerSamosbor() сделает reset, покажет диалог, и т.п.
    }

    /**
     * Кнопка "Окончание Самосбора"
     */
    @FXML
    private void onStop() {
        manager.stop();
        statusLabel.setText("Оценка случайного события завершена.");
    }

    /**
     * Вызывается раз в секунду (Timeline).
     * Обновляет отображение timeSinceLastSamosbor и eventTimer.
     */
    private void updateUI() {
        // Если самосбор идет (running) и не на паузе — обновляем лейблы
        if (manager.isRunning() && !manager.isPaused()) {
            lastSamosborLabel.setText(
                    "Время с последнего самосбора: " + manager.getTimeSinceLastSamosbor() + " сек."
            );
            overallTimerLabel.setText(
                    "Общее время: " + manager.getEventTimer() + " сек."
            );
        } else {
            // Если не идет или стоит на паузе, можно просто оставить те же значения
            // или показывать что-то особое
            // Но зачастую мы хотим всё время видеть "живые" счётчики
            // lastSamosborLabel.setText("На паузе / остановлено.");
        }
    }
}
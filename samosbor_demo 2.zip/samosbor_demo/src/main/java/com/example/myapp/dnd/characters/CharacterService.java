package com.example.myapp.dnd.characters;

import com.example.myapp.dnd.data.ClassData;
import com.example.myapp.dnd.storage.Storage;

import java.util.*;

public class CharacterService {

    private static final Random RANDOM = new Random();

    /**
     * Аналог create_character
     */
    public static Character createCharacter(
            String name,
            String charClass,
            int strength,
            int agility,
            int stamina
    ) {
        // 1. Проверка класса
        if (!ClassData.CLASSES.contains(charClass)) {
            throw new IllegalArgumentException("Некорректный класс: " + charClass);
        }

        // 2. Проверка суммы характеристик
        if (strength + agility + stamina > 3) {
            throw new IllegalArgumentException("Сумма (strength + agility + stamina) не должна превышать 3");
        }

        // 3. Генерация навыков на основе SKILL_RANGES
        Map<String, int[]> rangeMap = ClassData.SKILL_RANGES.get(charClass);
        Map<String, Integer> generatedSkills = new HashMap<>();
        for (Map.Entry<String, int[]> entry : rangeMap.entrySet()) {
            String skillName = entry.getKey();
            int[] bounds = entry.getValue();  // [min, max]
            int minVal = bounds[0];
            int maxVal = bounds[1];
            // Случайное значение
            int value = RANDOM.nextInt(maxVal - minVal + 1) + minVal;
            generatedSkills.put(skillName, value);
        }

        // 4. Пустые списки features/talents (или генерируем, если нужно)
        List<String> features = new ArrayList<>();
        List<String> talents = new ArrayList<>();

        // 5. Создаём объект Character
        Character character = new Character(
                name, charClass, strength, agility, stamina,
                generatedSkills,
                features,
                talents
        );

        // 6. Сохраняем
        Storage.saveCharacter(character);

        // 7. Возвращаем
        return character;
    }
}
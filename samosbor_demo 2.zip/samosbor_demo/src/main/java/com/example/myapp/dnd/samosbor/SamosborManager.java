package com.example.myapp.dnd.samosbor;

import javafx.application.Platform;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Аналог Python sСlassNameamosbor.py.
 * Отслеживает время, каждую секунду увеличивает счётчики.
 * Раз в 10 секунд - проверка события. Если выпадет 100, вызывается самосбор.
 */
public class SamosborManager {

    private boolean running = false;
    private boolean paused = false;

    private int timeSinceLastSamosbor = 0;  // Секунды с последнего самосбора
    private int eventTimer = 0;            // Общее время (в секундах)

    private int rangeMin = 0;
    private int rangeMax = 100;

    private final Random random = new Random();
    private ScheduledExecutorService scheduler;

    // Конструктор по умолчанию
    public SamosborManager() {
    }

    /**
     * Запустить оценку случайного события:
     * - создаём (или перезапускаем) фоновый поток,
     * - раз в 1 секунду: если running && !paused, увеличиваем eventTimer, timeSinceLastSamosbor,
     *   каждые 10 сек checkEvent(), каждые 60 сек (rangeMin += 5)...
     */
    public void start() {
        running = true;
        paused = false;

        // Если уже есть планировщик и он не закрыт, можно переиспользовать
        // но обычно лучше пересоздать
        if (scheduler == null || scheduler.isShutdown()) {
            scheduler = Executors.newSingleThreadScheduledExecutor();
        }

        // Раз в секунду выполняем run():
        scheduler.scheduleAtFixedRate(() -> {
            if (running && !paused) {
                eventTimer++;
                timeSinceLastSamosbor++;

                // Каждые 10 сек
                if (eventTimer % 10 == 0) {
                    checkEvent();
                }
                // Каждые 60 сек
                if (eventTimer % 60 == 0 && rangeMin < (rangeMax - 5)) {
                    rangeMin += 5;
                }
            }
        }, 1, 1, TimeUnit.SECONDS);
    }

    /**
     * Поставить на паузу
     */
    public void pause() {
        paused = true;
    }

    /**
     * Возобновить
     */
    public void resume() {
        paused = false;
    }

    /**
     * Остановить (завершить) самосбор.
     * (Можно дополнительно остановить scheduler, если не нужно больше перезапускать)
     */
    public void stop() {
        running = false;
        // Если хотите полностью освободить ресурсы:
        // if (scheduler != null) {
        //     scheduler.shutdown();
        // }
    }

    /**
     * Ручной (принудительный) запуск самосбора
     */
    public void manualSamosbor() {
        triggerSamosbor();
    }

    /**
     * Проверяем случайное событие:
     * - Бросаем random в диапазоне [rangeMin..rangeMax].
     * - Если = 100, вызываем самосбор
     */
    private void checkEvent() {
        int roll = random.nextInt(rangeMax - rangeMin + 1) + rangeMin;
        if (roll == 100) {
            triggerSamosbor();
        }
    }

    /**
     * Срабатывание самосбора:
     * - Останавливаем running
     * - Генерируем случайный alertStatus
     * - Показываем Alert (messagebox)
     * - Сбрасываем счётчики (resetSamosbor)
     */
    private void triggerSamosbor() {
        running = false;
        int alertStatus = random.nextInt(6) + 1;  // 1..6

        String alertMessage;
        if (alertStatus == 1 || alertStatus == 2) {
            alertMessage = "Система оповещения не работает.";
        } else if (alertStatus == 3 || alertStatus == 4) {
            alertMessage = "Система оповещения частично неисправна.";
        } else {
            alertMessage = "Система оповещения работает корректно.";
        }

        // Показать диалог в JavaFX-потоке
        Platform.runLater(() -> {
            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("Самосбор");
            alert.setHeaderText("Происходит самосбор!");
            alert.setContentText(alertMessage);
            alert.showAndWait();
        });

        resetSamosbor();
    }

    /**
     * Сбросить счётчики после срабатывания самосбора
     */
    private void resetSamosbor() {
        timeSinceLastSamosbor = 0;
        eventTimer = 0;
        rangeMin = 0;
        rangeMax = 100;
    }

    // --------------------------------------------------
    // Геттеры
    // --------------------------------------------------
    public boolean isRunning() {
        return running;
    }

    public boolean isPaused() {
        return paused;
    }

    public int getTimeSinceLastSamosbor() {
        return timeSinceLastSamosbor;
    }

    public int getEventTimer() {
        return eventTimer;
    }

    public int getRangeMin() {
        return rangeMin;
    }

    public int getRangeMax() {
        return rangeMax;
    }
}
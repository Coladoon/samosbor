package com.example.myapp.dnd.editor;

import com.example.myapp.dnd.characters.Character;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.util.Map;

public class CharacterEditorController {

    // Поле для ввода имени персонажа
    @FXML
    private TextField nameField;

    // Кнопка "Загрузить"
    @FXML
    private Button loadButton;

    // Метки (Labels) для отображения основных сведений
    @FXML
    private Label nameLabel;
    @FXML
    private Label classLabel;
    @FXML
    private Label levelLabel;
    @FXML
    private Label expLabel;

    // Метки или лейблы для статов
    @FXML
    private Label strengthLabel;
    @FXML
    private Label agilityLabel;
    @FXML
    private Label staminaLabel;

    // Поле для ввода опыта, который хотим добавить
    @FXML
    private TextField expEntry;

    // Текстовое поле (или TextArea) для отображения навыков
    @FXML
    private TextArea skillsArea;

    // Списки особенностей и талантов (если хотим их показывать)
    @FXML
    private ListView<String> featuresList;
    @FXML
    private ListView<String> talentsList;

    // Поле для ввода названия таланта, который хотим разблокировать
    @FXML
    private TextField talentEntry;

    // Общая метка для вывода статуса/ошибок
    @FXML
    private Label resultLabel;

    // Текущий загруженный персонаж
    private com.example.myapp.dnd.characters.Character currentCharacter;

    @FXML
    public void initialize() {
        // Можно инициализировать списки, если нужно
        // Например:
        // featuresList.setItems(FXCollections.observableArrayList());
        // talentsList.setItems(FXCollections.observableArrayList());
    }

    /**
     * Вызывается по нажатию кнопки "Загрузить".
     * Загружает персонажа по имени, если он существует, и обновляет UI.
     */
    @FXML
    private void onLoadCharacter() {
        String name = nameField.getText().trim();
        if (name.isEmpty()) {
            resultLabel.setText("Введите имя персонажа.");
            return;
        }

        // Используем сервисную функцию, аналогичную load_character в Python
        Character loaded = CharacterEditorService.loadCharacter(name);
        if (loaded == null) {
            resultLabel.setText("Персонаж \"" + name + "\" не найден.");
            return;
        }

        currentCharacter = loaded;
        resultLabel.setText("Персонаж \"" + loaded.getName() + "\" загружен.");
        updateUI();
    }

    /**
     * Кнопки + / - для статов.
     * Можно сделать отдельные методы "onIncreaseStrength", "onDecreaseStrength" и т.п.
     */
    @FXML
    private void onIncreaseStrength() {
        modifyStat("strength", 1);
    }

    @FXML
    private void onDecreaseStrength() {
        modifyStat("strength", -1);
    }

    @FXML
    private void onIncreaseAgility() {
        modifyStat("agility", 1);
    }

    @FXML
    private void onDecreaseAgility() {
        modifyStat("agility", -1);
    }

    @FXML
    private void onIncreaseStamina() {
        modifyStat("stamina", 1);
    }

    @FXML
    private void onDecreaseStamina() {
        modifyStat("stamina", -1);
    }

    /**
     * Добавить опыт (берём значение из expEntry)
     */
    @FXML
    private void onAddExperience() {
        if (currentCharacter == null) {
            resultLabel.setText("Сначала загрузите персонажа.");
            return;
        }
        try {
            int amount = Integer.parseInt(expEntry.getText().trim());
            modifyStat("experience", amount);
        } catch (NumberFormatException e) {
            resultLabel.setText("Некорректное число опыта.");
        }
    }

    /**
     * Разблокировать талант (берём название из talentEntry)
     */
    @FXML
    private void onUnlockTalent() {
        if (currentCharacter == null) {
            resultLabel.setText("Сначала загрузите персонажа.");
            return;
        }
        String talentName = talentEntry.getText().trim();
        if (talentName.isEmpty()) {
            resultLabel.setText("Введите название таланта.");
            return;
        }
        boolean success = CharacterEditorService.unlockTalent(currentCharacter, talentName);
        if (success) {
            CharacterEditorService.saveChanges(currentCharacter);
            resultLabel.setText("Талант \"" + talentName + "\" разблокирован!");
            updateUI();
        } else {
            resultLabel.setText("Талант \"" + talentName + "\" не найден.");
        }
    }

    /**
     * Показать описание выбранной особенности (из ListView featuresList)
     */
    @FXML
    private void onShowFeatureDescription() {
        if (currentCharacter == null) {
            resultLabel.setText("Сначала загрузите персонажа.");
            return;
        }
        String selectedFeature = featuresList.getSelectionModel().getSelectedItem();
        if (selectedFeature != null) {
            String desc = CharacterEditorService.getDescription(selectedFeature);
            showInfoDialog(selectedFeature, desc);
        }
    }

    /**
     * Показать описание выбранного таланта (из ListView talentsList)
     */
    @FXML
    private void onShowTalentDescription() {
        if (currentCharacter == null) {
            resultLabel.setText("Сначала загрузите персонажа.");
            return;
        }
        String selectedTalent = talentsList.getSelectionModel().getSelectedItem();
        if (selectedTalent != null) {
            String desc = CharacterEditorService.getDescription(selectedTalent);
            showInfoDialog(selectedTalent, desc);
        }
    }

    /**
     * Вспомогательный метод для изменения стата через сервис.
     */
    private void modifyStat(String stat, int delta) {
        if (currentCharacter == null) {
            resultLabel.setText("Сначала загрузите персонажа.");
            return;
        }
        CharacterEditorService.modifyStat(currentCharacter, stat, delta);
        // Сохраняем
        CharacterEditorService.saveChanges(currentCharacter);
        resultLabel.setText("Стат " + stat + (delta > 0 ? " увеличен" : " уменьшен")
                + " на " + Math.abs(delta));
        updateUI();
    }

    /**
     * Обновить UI (лейблы, списки и т. п.)
     */
    private void updateUI() {
        if (currentCharacter == null) return;

        // Основные поля
        nameLabel.setText("Имя: " + currentCharacter.getName());
        classLabel.setText("Класс: " + currentCharacter.getCharClass());
        levelLabel.setText("Уровень: " + currentCharacter.getLevel());
        expLabel.setText("Опыт: " + currentCharacter.getExperience());

        // Статы
        strengthLabel.setText("Сила: " + currentCharacter.getStrength());
        agilityLabel.setText("Ловкость: " + currentCharacter.getAgility());
        staminaLabel.setText("Выносливость: " + currentCharacter.getStamina());

        // Навыки
        if (currentCharacter.getSkills() != null) {
            StringBuilder sb = new StringBuilder();
            for (Map.Entry<String, Integer> e : currentCharacter.getSkills().entrySet()) {
                sb.append(e.getKey()).append(": ").append(e.getValue()).append("\n");
            }
            skillsArea.setText(sb.toString());
        } else {
            skillsArea.clear();
        }

        // Особенности
        if (currentCharacter.getFeatures() != null) {
            featuresList.getItems().setAll(currentCharacter.getFeatures());
        } else {
            featuresList.getItems().clear();
        }

        // Таланты
        if (currentCharacter.getTalents() != null) {
            talentsList.getItems().setAll(currentCharacter.getTalents());
        } else {
            talentsList.getItems().clear();
        }
    }

    /**
     * Показывает простое диалоговое окно с заголовком itemName и текстом desc.
     */
    private void showInfoDialog(String itemName, String desc) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Описание");
        alert.setHeaderText(itemName);
        alert.setContentText(desc);
        alert.showAndWait();
    }
}
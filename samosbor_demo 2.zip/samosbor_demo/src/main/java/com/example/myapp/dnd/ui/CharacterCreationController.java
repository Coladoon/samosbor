package com.example.myapp.dnd.ui;

import com.example.myapp.dnd.characters.Character;
import com.example.myapp.dnd.characters.CharacterService;
import com.example.myapp.dnd.data.ClassData;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class CharacterCreationController {

    @FXML
    private TextField nameField;

    @FXML
    private ComboBox<String> classCombo;

    @FXML
    private Spinner<Integer> strengthSpinner;

    @FXML
    private Spinner<Integer> agilitySpinner;

    @FXML
    private Spinner<Integer> staminaSpinner;

    @FXML
    private Label resultLabel;

    @FXML
    public void initialize() {
        // Заполняем comboBox названиями классов
        classCombo.getItems().addAll(ClassData.CLASSES);
        // По умолчанию выбираем первый элемент
        if (!ClassData.CLASSES.isEmpty()) {
            classCombo.getSelectionModel().select(0);
        }

        // Настраиваем спиннеры (0..3)
        strengthSpinner.setValueFactory(
                new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 3, 0)
        );
        agilitySpinner.setValueFactory(
                new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 3, 0)
        );
        staminaSpinner.setValueFactory(
                new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 3, 0)
        );
    }

    @FXML
    private void onCreateCharacter() {
        try {
            String name = nameField.getText().trim();
            String selectedClass = classCombo.getValue();
            int strength = strengthSpinner.getValue();
            int agility = agilitySpinner.getValue();
            int stamina = staminaSpinner.getValue();

            // Вызов сервиса, который создаст и сохранит персонажа
            Character character = CharacterService.createCharacter(
                    name, selectedClass, strength, agility, stamina
            );

            // Если всё ок, выводим сообщение
            resultLabel.setText("Персонаж " + character.getName() + " успешно создан!");
            resultLabel.setStyle("-fx-text-fill: green;");

        } catch (Exception e) {
            // Любые ошибки (например, сумма статов > 3) отобразим красным
            resultLabel.setText("Ошибка: " + e.getMessage());
            resultLabel.setStyle("-fx-text-fill: red;");
        }
    }
}
package com.example.myapp.dnd.characters;

import java.util.List;
import java.util.Map;

public class Character {
    private String name;
    private String charClass;
    private int strength;
    private int agility;
    private int stamina;
    private Map<String, Integer> skills;
    private List<String> features;
    private List<String> talents;
    private int experience;
    private int level;

    // Gson/Jackson нужны пустой конструктор по умолчанию
    public Character() {
    }

    // Дополнительный конструктор, если хотим
    public Character(String name, String charClass,
                     int strength, int agility, int stamina,
                     Map<String, Integer> skills,
                     List<String> features,
                     List<String> talents) {
        this.name = name;
        this.charClass = charClass;
        this.strength = strength;
        this.agility = agility;
        this.stamina = stamina;
        this.skills = skills;
        this.features = features;
        this.talents = talents;
        this.experience = 0;
        this.level = 0;
    }

    // getters/setters

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getCharClass() { return charClass; }
    public void setCharClass(String charClass) { this.charClass = charClass; }

    public int getStrength() { return strength; }
    public void setStrength(int strength) { this.strength = strength; }

    public int getAgility() { return agility; }
    public void setAgility(int agility) { this.agility = agility; }

    public int getStamina() { return stamina; }
    public void setStamina(int stamina) { this.stamina = stamina; }

    public Map<String, Integer> getSkills() { return skills; }
    public void setSkills(Map<String, Integer> skills) { this.skills = skills; }

    public List<String> getFeatures() { return features; }
    public void setFeatures(List<String> features) { this.features = features; }

    public List<String> getTalents() { return talents; }
    public void setTalents(List<String> talents) { this.talents = talents; }

    public int getExperience() { return experience; }
    public void setExperience(int experience) { this.experience = experience; }

    public int getLevel() { return level; }
    public void setLevel(int level) { this.level = level; }
}
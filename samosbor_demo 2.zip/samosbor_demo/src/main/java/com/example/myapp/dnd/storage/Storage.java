package com.example.myapp.dnd.storage;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.example.myapp.dnd.characters.Character;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Аналог storage.py из Python.
 * Сохраняет/загружает персонажа в JSON-файл <Имя>.json.
 * Хранит все файлы в папке "characters_storage".
 */
public class Storage {

    // Путь к папке, где лежат JSON-файлы персонажей
    private static final Path STORAGE_DIR = Paths.get("characters_storage");

    // Настраиваем Gson (Pretty Printing, если хотите отформатированный JSON)
    private static final Gson GSON = new GsonBuilder()
            .setPrettyPrinting()
            .create();

    static {
        // Создаём директорию, если она ещё не существует
        try {
            Files.createDirectories(STORAGE_DIR);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Сохраняет персонажа в файл <Name>.json
     */
    public static void saveCharacter(Character character) {
        // Название файла = "<Name>.json"
        String fileName = character.getName() + ".json";
        Path filePath = STORAGE_DIR.resolve(fileName);

        // Пишем JSON
        try (Writer writer = Files.newBufferedWriter(filePath)) {
            GSON.toJson(character, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Загружает персонажа по имени (без .json),
     * возвращает null, если файла нет или произошла ошибка.
     */
    public static Character loadCharacter(String characterName) {
        // Путь к файлу
        String fileName = characterName + ".json";
        Path filePath = STORAGE_DIR.resolve(fileName);

        if (!Files.exists(filePath)) {
            // Файла нет — нет такого персонажа
            return null;
        }

        try (Reader reader = Files.newBufferedReader(filePath)) {
            // Считываем JSON в объект Character
            return GSON.fromJson(reader, Character.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Возвращает список всех имён персонажей (т.е. все .json без расширения)
     */
    public static List<String> listCharacters() {
        if (!Files.exists(STORAGE_DIR)) {
            return Collections.emptyList();
        }

        List<String> names = new ArrayList<>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(STORAGE_DIR, "*.json")) {
            for (Path path : stream) {
                String fileName = path.getFileName().toString();
                // "John.json" -> "John"
                if (fileName.endsWith(".json")) {
                    names.add(fileName.substring(0, fileName.length() - 5));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return names;
    }

    /**
     * Удаляет персонажа (файл <Name>.json).
     * Возвращает true, если удалён успешно.
     */
    public static boolean deleteCharacter(String characterName) {
        Path filePath = STORAGE_DIR.resolve(characterName + ".json");
        if (Files.exists(filePath)) {
            try {
                Files.delete(filePath);
                return true;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return false;
    }
}
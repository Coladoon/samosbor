package com.example.myapp.dnd.ui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainMenuController {

    // Этот метод вызывается при нажатии на кнопку "Создать персонажа"
    @FXML
    private void onCreateCharacter(ActionEvent event) {
        try {
            // 1. Загружаем FXML окна создания персонажа
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/character-creation.fxml"));
            Parent root = loader.load();

            // 2. Создаём новое окно (Stage) или меняем сцену в текущем
            Stage stage = new Stage();
            stage.setTitle("Создание персонажа");
            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Этот метод вызывается при нажатии на кнопку "Редактор персонажа"
    @FXML
    private void onOpenEditor(ActionEvent event) {
        try {
            // 1. Загружаем FXML окна редактора
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/character-editor.fxml"));
            Parent root = loader.load();

            // 2. Открываем новое окно
            Stage stage = new Stage();
            stage.setTitle("Редактор персонажа");
            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Этот метод вызывается при нажатии на кнопку "Система Самосбор"
    @FXML
    private void onOpenSamosbor(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/samosbor.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Система Самосбор");
            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
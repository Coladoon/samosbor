module com.example.samosbor_demo {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson; // если используете Gson

    // Открываем пакеты с контроллерами для FXML
    opens com.example.myapp.dnd.ui to javafx.fxml;
    opens com.example.myapp.dnd.editor to javafx.fxml;
    opens com.example.myapp.dnd.samosbor to javafx.fxml;

    // Если Gson нужен для моделей:
    opens com.example.myapp.dnd.data to com.google.gson;
    opens com.example.myapp.dnd.characters to com.google.gson;
}
